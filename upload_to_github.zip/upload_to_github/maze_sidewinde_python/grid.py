from cell import Cell
from PIL import Image, ImageDraw

class Grid:
    def __init__(self, rows, cols):
        self.rows = rows
        self.cols = cols
        self.grid = self.prepare_grid()
        self.configure_cells()  # 👈 加上这行！

    def prepare_grid(self):
        return [[Cell(row, col) for col in range(self.cols)] for row in range(self.rows)]

    def each_cell(self):
        for row in self.grid:
            for cell in row:
                yield cell

    def configure_cells(self):
        """
        设置每个格子的上下左右邻居
        """
        for row in self.grid:
            for cell in row:
                r, c = cell.row, cell.col
                cell.north = self[r - 1, c] if r > 0 else None
                cell.south = self[r + 1, c] if r < self.rows - 1 else None
                cell.west  = self[r, c - 1] if c > 0 else None
                cell.east  = self[r, c + 1] if c < self.cols - 1 else None

    def __getitem__(self, pos):
        r, c = pos
        return self.grid[r][c]

    def display(self):
        for row in self.grid:
            for cell in row:
                print(cell, end="  ")
            print()

    def to_s(self, cell_width=3):
        output = "+" + ("-" * cell_width + "+") * self.cols + "\n"

        for row in self.grid:
            top = "|"
            bottom = "+"

            for cell in row:
                content = self.contents_of(cell)
                body = content.center(cell_width)  # 👈 内容居中
                east = " " if cell.is_linked(cell.east) else "|"
                top += body + east

                south = " " * cell_width if cell.is_linked(cell.south) else "-" * cell_width
                corner = "+"
                bottom += south + corner

            output += top + "\n"
            output += bottom + "\n"

        return output

    def to_png(self, cell_size=20, wall_color=(0, 0, 0), bg_color=(255, 255, 255)):
        img_width = self.cols * cell_size
        img_height = self.rows * cell_size

        img = Image.new("RGB", (img_width + 1, img_height + 1), bg_color)
        draw = ImageDraw.Draw(img)

        for cell in self.each_cell():
            x1 = cell.col * cell_size
            y1 = cell.row * cell_size
            x2 = (cell.col + 1) * cell_size
            y2 = (cell.row + 1) * cell_size

            # 背景染色（调用 DistanceGrid 的 background_color_for）
            if hasattr(self, "background_color_for"):
                color = self.background_color_for(cell)
                if color:
                    draw.rectangle([x1, y1, x2, y2], fill=color)

            # 画墙
            if not cell.north:
                draw.line([(x1, y1), (x2, y1)], fill=wall_color)
            if not cell.west:
                draw.line([(x1, y1), (x1, y2)], fill=wall_color)
            if not cell.is_linked(cell.east):
                draw.line([(x2, y1), (x2, y2)], fill=wall_color)
            if not cell.is_linked(cell.south):
                draw.line([(x1, y2), (x2, y2)], fill=wall_color)

        return img