class Cell:
    def __init__(self,row,col):
        self.row = row
        self.col = col
        self.north = None
        self.west = None
        self.east = None
        self.south = None
        self._links = {}

    
    def __repr__(self):
        return f"Cell({self.row},{self.col})"
    
    def link(self,other,bidirectional=True): 
        self._links[other] = True
        if bidirectional:
            other.link(self,False)


    def is_linked(self, other):
        """
        判断是否与另一个 cell 相连
        """
        return other in self._links

    def get_links(self):
        """
        返回所有链接的 cell 列表
        """
        return list(self._links.keys())
    
    def distances(self):
        from distance import Distances  # 延迟导入，防止循环引用

        distances = Distances(self)
        frontier = [self]

        while frontier:
            new_frontier = []
            for cell in frontier:
                for neighbor in cell.get_links():
                    if distances[neighbor] is None:
                        distances[neighbor] = distances[cell] + 1
                        new_frontier.append(neighbor)
            frontier = new_frontier

        return distances
