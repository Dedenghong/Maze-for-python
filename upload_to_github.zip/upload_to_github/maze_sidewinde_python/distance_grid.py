from grid import Grid
from PIL import ImageColor


class DistanceGrid(Grid):
    def __init__(self, rows, cols):
        super().__init__(rows, cols)
        self._distances = None  

    def set_distances(self, distances):
        self._distances = distances

    def contents_of(self, cell):
        if self._distances is not None and self._distances[cell] is not None:
            return str(self._distances[cell]).rjust(2)  
        else:
            return "  "
        
    def background_color_for(self, cell):
        if not self._distances or self._distances[cell] is None:
            return None

        max_distance = max(self._distances._cells.values())
        distance = self._distances[cell]

        # 颜色强度：越远颜色越深
        intensity = (max_distance - distance) / max(max_distance, 1)
        dark = int(255 * intensity)
        bright = 255 - dark

        return (bright, dark, dark)  # 红色渐变

        
    
