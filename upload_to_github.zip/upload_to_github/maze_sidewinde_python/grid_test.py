from grid import Grid

grid = Grid(3, 4)  
grid.display()
