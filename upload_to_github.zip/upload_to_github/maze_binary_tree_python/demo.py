# from distance_grid import DistanceGrid
# from binary_tree import BinaryTree

# grid = DistanceGrid(5, 5)
# BinaryTree.on(grid)

# start = grid[0, 0]
# distances = start.distances()

# # ✔️ 终点：比如最远点，或 grid[rows-1, 0]
# goal = grid[grid.rows - 1, 0]  # 左下角
# # 或：goal, _ = distances.max()

# # ✔️ 得到路径
# path = distances.path_to(goal)

# # ✔️ 设置路径到 grid
# grid.set_distances(path)

# # ✔️ 打印输出
# print(grid.to_s())

from distance_grid import DistanceGrid
from binary_tree import BinaryTree
from PIL import Image



# 1. 创建迷宫并生成通路
rows, cols = 10, 10
grid = DistanceGrid(rows, cols)
BinaryTree.on(grid)

# 2. 穷举所有点作为起点，寻找最长路径
longest_len = 0
best_start = None
best_goal = None
best_path = None

for cell in grid.each_cell():
    distances = cell.distances()
    goal, distance = distances.max()  # 找到从该点出发能到达的最远点
    if distance > longest_len:
        longest_len = distance
        best_start = cell
        best_goal = goal
        best_path = distances.path_to(goal)

# 3. 设置这条“最远路径”作为可视化对象
grid.set_distances(best_path)

# 4. 打印结果
print(f"最佳起点是：{best_start}")
print(f"终点是：{best_goal}")
print(f"最长路径长度为：{longest_len} 步")
print()
print(grid.to_s())  # 可视化显示路径
# 生成 PNG 图片
img = grid.to_png(cell_size=20)
img.save("longest_path.png")
print("PNG 图片已保存为 longest_path.png")
